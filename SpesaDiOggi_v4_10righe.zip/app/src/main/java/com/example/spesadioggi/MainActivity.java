package com.example.spesadioggi;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 9;
    private static final int REQUEST_SPEECH = 10;
    private final int BLUE_BG = Color.rgb(185, 221, 240);
    private final int BLUE = Color.rgb(21, 101, 192);
    private final int BLACK = Color.rgb(20, 25, 30);

    private LinearLayout list, bought;
    private TextView status, emptyList, emptyBought;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("spesa", MODE_PRIVATE);
        build();
        loadSaved();
    }

    private TextView makeText(String s, float size) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(BLACK);
        v.setTextSize(size);
        v.setPadding(16, 12, 16, 12);
        return v;
    }

    private TextView sectionTitle(String s) {
        TextView v = makeText(s, 18);
        v.setTypeface(null, android.graphics.Typeface.BOLD);
        v.setPadding(4, 22, 4, 8);
        return v;
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(18, 20, 18, 30);
        page.setBackgroundColor(BLUE_BG);

        TextView title = makeText("🛒  Spesa di Oggi", 30);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        page.addView(title);

        TextView subtitle = makeText("Dilla a voce. Al resto pensiamo noi.", 15);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle);

        Button mic = new Button(this);
        mic.setText("  PARLA");
        mic.setTextSize(21);
        mic.setTextColor(Color.WHITE);
        mic.setTypeface(null, android.graphics.Typeface.BOLD);
        mic.setAllCaps(false);
        mic.setGravity(Gravity.CENTER);
        mic.setBackgroundResource(R.drawable.mic_button);
        mic.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_mic, 0, 0, 0);
        mic.setCompoundDrawablePadding(10);
        mic.setContentDescription("Parla per aggiungere prodotti alla spesa");

        LinearLayout.LayoutParams micParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 82);
        micParams.setMargins(0, 18, 0, 8);
        page.addView(mic, micParams);

        status = makeText("Tocca PARLA e detta quello che ti serve.", 15);
        status.setGravity(Gravity.CENTER);
        page.addView(status);

        page.addView(sectionTitle("DA COMPRARE"));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(list);

        emptyList = makeText("La lista è vuota.\nPremi PARLA per iniziare.", 17);
        emptyList.setGravity(Gravity.CENTER);
        emptyList.setPadding(20, 30, 20, 30);
        list.addView(emptyList);

        page.addView(sectionTitle("COMPRATI"));
        bought = new LinearLayout(this);
        bought.setOrientation(LinearLayout.VERTICAL);
        page.addView(bought);

        emptyBought = makeText("Nessun prodotto comprato.", 16);
        emptyBought.setGravity(Gravity.CENTER);
        emptyBought.setPadding(20, 24, 20, 24);
        bought.addView(emptyBought);

        TextView hint = makeText("💡 Tocca un prodotto per spostarlo tra DA COMPRARE e COMPRATI.", 13);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(10, 26, 10, 8);
        page.addView(hint);

        scroll.addView(page);
        setContentView(scroll);

        mic.setOnClickListener(v -> startListening());
    }

    private void loadSaved() {
        loadArray("to_buy", false);
        loadArray("bought", true);
        refreshEmpty();
    }

    private void loadArray(String key, boolean isBought) {
        try {
            JSONArray a = new JSONArray(prefs.getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) {
                addItem(a.optString(i), isBought, false);
            }
        } catch (Exception ignored) {}
    }

    private void addItem(String product, boolean isBought, boolean save) {
        if (product == null || product.trim().isEmpty()) return;
        removeEmptyViews();

        final String clean = product.trim();
        TextView item = makeText((isBought ? "✓  " : "☐  ") + clean, 18);
        item.setTypeface(null, android.graphics.Typeface.BOLD);
        item.setBackgroundResource(isBought ? R.drawable.bought_card : R.drawable.item_card);

        LinearLayout target = isBought ? bought : list;
        item.setOnClickListener(v -> {
            if (isBought) {
                bought.removeView(item);
                addItem(clean, false, true);
            } else {
                list.removeView(item);
                addItem(clean, true, true);
            }
            saveAll();
            refreshEmpty();
        });

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 5, 0, 5);
        target.addView(item, p);

        if (save) saveAll();
    }

    private void removeEmptyViews() {
        if (emptyList.getParent() != null) list.removeView(emptyList);
        if (emptyBought.getParent() != null) bought.removeView(emptyBought);
    }

    private void refreshEmpty() {
        if (list.getChildCount() == 0) list.addView(emptyList);
        if (bought.getChildCount() == 0) bought.addView(emptyBought);
    }

    private void startListening() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        listenNow();
    }

    private void listenNow() {
        status.setText("🎙️  Ti ascolto…");
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,
                "Dimmi cosa devo aggiungere alla spesa");
        try {
            startActivityForResult(i, REQUEST_SPEECH);
        } catch (Exception e) {
            status.setText("Il riconoscimento vocale non è disponibile.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_AUDIO &&
                results.length > 0 &&
                results[0] == PackageManager.PERMISSION_GRANTED) {
            listenNow();
        } else if (requestCode == REQUEST_AUDIO) {
            status.setText("Serve il permesso del microfono per usare PARLA.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_SPEECH) return;

        if (resultCode == RESULT_OK && data != null) {
            ArrayList<String> results =
                    data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String spoken = results.get(0).trim();
                List<String> products = splitProducts(spoken);
                for (String p : products) addItem(cleanSpeech(p), false, false);
                saveAll();
                status.setText(products.size() == 1
                        ? "Aggiunto alla lista."
                        : products.size() + " prodotti aggiunti.");
            } else {
                status.setText("Non ho ricevuto nessun prodotto.");
            }
        } else {
            status.setText("Nessun prodotto aggiunto.");
        }
    }

    private List<String> splitProducts(String spoken) {
        ArrayList<String> out = new ArrayList<>();
        String[] parts = spoken.split("\\s*[,;]\\s*|\\n+");
        for (String p : parts) {
            if (!p.trim().isEmpty()) out.add(p.trim());
        }
        if (out.isEmpty()) out.add(spoken);
        return out;
    }

    private String cleanSpeech(String s) {
        String x = s.trim();
        if (x.length() > 0) x = Character.toUpperCase(x.charAt(0)) + x.substring(1);
        return x;
    }

    private void saveAll() {
        saveList("to_buy", list);
        saveList("bought", bought);
    }

    private void saveList(String key, LinearLayout container) {
        JSONArray a = new JSONArray();
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child instanceof TextView && child != emptyList && child != emptyBought) {
                String s = ((TextView) child).getText().toString();
                if (s.startsWith("☐  ")) s = s.substring(3);
                if (s.startsWith("✓  ")) s = s.substring(3);
                try { a.put(s); } catch (Exception ignored) {}
            }
        }
        prefs.edit().putString(key, a.toString()).apply();
    }
}
